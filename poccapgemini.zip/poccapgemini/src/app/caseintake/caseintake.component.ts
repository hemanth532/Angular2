import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caseintake',
  templateUrl: './caseintake.component.html',
  styleUrls: ['./caseintake.component.css']
})
export class CaseintakeComponent implements OnInit {
  foods = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  constructor() { }

  ngOnInit() {
  }

}
