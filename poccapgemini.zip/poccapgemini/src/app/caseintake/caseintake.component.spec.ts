import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseintakeComponent } from './caseintake.component';

describe('CaseintakeComponent', () => {
  let component: CaseintakeComponent;
  let fixture: ComponentFixture<CaseintakeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseintakeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseintakeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
