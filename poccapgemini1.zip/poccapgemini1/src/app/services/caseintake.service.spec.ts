import { TestBed, inject } from '@angular/core/testing';

import { CaseintakeService } from './caseintake.service';

describe('CaseintakeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CaseintakeService]
    });
  });

  it('should be created', inject([CaseintakeService], (service: CaseintakeService) => {
    expect(service).toBeTruthy();
  }));
});
