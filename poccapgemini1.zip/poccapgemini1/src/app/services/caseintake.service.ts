import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import {HttpClient,HttpHeaders} from "@angular/common/http";
import {contentHeaders} from "../common/auth-headers";
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CaseintakeService {

  basePath: string = environment.apiUrl;

  constructor( private http: HttpClient) { }

  caseIntake(object) {
    console.log('object'+JSON.stringify(object))
   let url = this.basePath+"generatecode/get/";
    console.log('url'+url);
    return this.http.post(url,{headers: contentHeaders},object);
  }
 
}
