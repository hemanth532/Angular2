import { Component, OnInit } from '@angular/core';
import{CaseintakeService} from './../services/caseintake.service'

@Component({
  selector: 'app-caseintake',
  templateUrl: './caseintake.component.html',
  styleUrls: ['./caseintake.component.css']
})
export class CaseintakeComponent implements OnInit {
  foods = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  caseIntkaeObj:any = {};

  constructor(private saseintakeservice:CaseintakeService) { }

  ngOnInit() {
  }
  submit(){
    return this.saseintakeservice.caseIntake(this.caseIntkaeObj).subscribe(response => {
        console.log(response);
    },
    error=>{
      console.log('error'+JSON.stringify(error));
    }
  );
  }
}
